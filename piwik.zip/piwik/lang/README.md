## Contribute

If you want to improve an existing Matomo translation or contribute a new translation, please have a look at our [Transifex project](https://translations.piwik.org).

We cannot accept pull requests for translations on GitHub since we manage all translations in this separate system. Translations will automatically be transferred to GitHub from time to time!

If you have any questions feel free to contact the team at translations@matomo.org.
